package com.metronom.tictactoe.utils.enums;

public enum GameOption {
    USERVSUSER,USERVSCOMPUTER,USERSVSCOMPUTER,COMPUTERVSCOMPUTER
}
