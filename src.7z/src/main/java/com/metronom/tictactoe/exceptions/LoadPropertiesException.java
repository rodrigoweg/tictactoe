package com.metronom.tictactoe.exceptions;

public class LoadPropertiesException extends Throwable {

    public LoadPropertiesException(String msg) {
        super(msg);
    }
}
