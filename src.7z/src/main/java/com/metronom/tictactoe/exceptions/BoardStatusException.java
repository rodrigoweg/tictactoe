package com.metronom.tictactoe.exceptions;

public class BoardStatusException extends Throwable {
    public BoardStatusException(String msg) {
        super(msg);
    }
}
