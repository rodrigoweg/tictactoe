package com.metronom.tictactoe.exceptions;

public class InvalidFormatMovementException extends Throwable {
    public InvalidFormatMovementException(String msg) {
        super(msg);
    }
}
