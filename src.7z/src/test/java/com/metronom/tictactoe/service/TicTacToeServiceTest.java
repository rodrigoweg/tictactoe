package com.metronom.tictactoe.service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class TicTacToeServiceTest {

    @Test
    public void propertyLoader() {
    }

    @Test
    public void initGame() {
    }

    @Test
    public void propertiesLoadSuccess() {
    }

    @Test
    public void propertiesLoadError() {
    }

    @Test
    public void printBoard() {
    }

    @Test
    public void nextPlayer() {
    }

    @Test
    public void nextMove() {
    }

    @Test
    public void evaluateBoard() {
    }

}
